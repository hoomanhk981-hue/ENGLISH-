'use strict';

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const GROUPS_FILE = path.join(DATA_DIR, 'groups.json');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJSON(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    console.error('خطا در خواندن فایل ذخیره‌سازی:', file, e.message);
    return fallback;
  }
}

function writeJSON(file, data) {
  ensureDataDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ---- مدیریت گروه‌ها ----
function getGroups() {
  return readJSON(GROUPS_FILE, []);
}

function getGroupIds() {
  return getGroups().map((g) => g.id);
}

function addGroup(chatId, info = {}) {
  const groups = getGroups();
  if (!groups.some((g) => g.id === chatId)) {
    groups.push({
      id: chatId,
      title: info.title || '',
      type: info.type || '',
      addedAt: Date.now(),
    });
    writeJSON(GROUPS_FILE, groups);
    return true;
  }
  // به‌روزرسانی عنوان در صورت تغییر
  const g = groups.find((x) => x.id === chatId);
  if (g && info.title && g.title !== info.title) {
    g.title = info.title;
    writeJSON(GROUPS_FILE, groups);
  }
  return false;
}

function removeGroup(chatId) {
  const groups = getGroups().filter((g) => g.id !== chatId);
  writeJSON(GROUPS_FILE, groups);
}

module.exports = {
  getGroups,
  getGroupIds,
  addGroup,
  removeGroup,
};
