'use strict';

const config = require('./config');

const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

/**
 * ارسال درخواست به OpenRouter و دریافت متن پاسخ.
 * مدل‌ها به ترتیب امتحان می‌شوند تا اولین مدلِ درست‌کار استفاده شود.
 *
 * @param {Array<{role:string,content:string}>} messages
 * @param {{models?:string[], temperature?:number, maxTokens?:number}} options
 * @returns {Promise<string>}
 */
async function complete(messages, options = {}) {
  const models = options.models && options.models.length
    ? options.models
    : config.aiModels;

  let lastError = null;

  for (const model of models) {
    try {
      const body = {
        model,
        messages,
        temperature: options.temperature != null ? options.temperature : 0.7,
      };
      if (options.maxTokens) {
        body.max_tokens = options.maxTokens;
      }

      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.openrouterKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': config.appUrl,
          'X-Title': config.appName,
        },
        body: JSON.stringify(body),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        const msg =
          (data && data.error && (data.error.message || data.error)) ||
          `HTTP ${res.status}`;
        lastError = new Error(
          typeof msg === 'string' ? msg : JSON.stringify(msg)
        );
        console.error(`[OpenRouter] مدل ${model} ناموفق:`, lastError.message);
        continue;
      }

      const content =
        data &&
        data.choices &&
        data.choices[0] &&
        data.choices[0].message &&
        data.choices[0].message.content;

      if (content && String(content).trim()) {
        return String(content).trim();
      }
      lastError = new Error('پاسخ خالی از مدل دریافت شد');
    } catch (e) {
      lastError = e;
      console.error(`[OpenRouter] خطای شبکه برای مدل ${model}:`, e.message);
    }
  }

  throw lastError || new Error('خطای ناشناخته در ارتباط با هوش مصنوعی');
}

module.exports = { complete };
