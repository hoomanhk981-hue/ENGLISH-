// تنظیمات PM2 برای اجرای دائمی ربات روی سرور (VPS)
// اجرا:  pm2 start ecosystem.config.js
module.exports = {
  apps: [
    {
      name: 'telegram-ai-bot',
      script: 'index.js',
      cwd: __dirname,
      autorestart: true,
      max_restarts: 20,
      min_uptime: '10s',
      time: true,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
