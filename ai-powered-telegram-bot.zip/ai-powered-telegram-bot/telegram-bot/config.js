'use strict';
// بارگذاری متغیرهای محیطی از فایل .env (اختیاری)
require('dotenv').config();

/**
 * تنظیمات ربات.
 * توکن‌ها به‌صورت پیش‌فرض داخل کد قرار داده شده‌اند و بدون هیچ تنظیمی کار می‌کنند.
 * اگر فایل .env بسازید و متغیرها را آنجا تعریف کنید، مقدار فایل .env اولویت دارد.
 */
const config = {
  // --- توکن ربات تلگرام ---
  telegramToken:
    process.env.TELEGRAM_BOT_TOKEN ||
    '8844082627:AAF4zMoXKaCieEHV0kMgrIdipl1oZuhfiAI',

  // --- کلید OpenRouter ---
  openrouterKey:
    process.env.OPENROUTER_API_KEY ||
    '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',

  // --- رمز پنل مدیریت ---
  adminPassword: process.env.ADMIN_PASSWORD || 'HKKINGROOT',

  // --- مدل‌های هوش مصنوعی (به ترتیب اولویت امتحان می‌شوند) ---
  // این مدل‌ها رایگان هستند؛ اگر اعتبار دارید می‌توانید مدل‌های پولی مثل
  // 'deepseek/deepseek-chat' یا 'openai/gpt-4o-mini' را جایگزین کنید.
  aiModels: process.env.AI_MODELS
    ? process.env.AI_MODELS.split(',').map((m) => m.trim()).filter(Boolean)
    : [
        'inclusionai/ling-3.0-flash:free',
        'google/gemma-4-31b-it:free',
        'openrouter/free',
        'openai/gpt-oss-20b:free',
      ],

  appName: process.env.APP_NAME || 'Telegram AI Bot',
  appUrl: process.env.APP_URL || 'https://t.me',

  // حداکثر تعداد پیام‌های ذخیره‌شده در حافظه مکالمه (برای هر کاربر)
  maxHistory: 20,
};

module.exports = config;
