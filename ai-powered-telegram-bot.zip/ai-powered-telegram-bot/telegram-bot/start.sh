#!/usr/bin/env bash
# اسکریپت اجرای ساده‌ی ربات روی لینوکس (VPS)
set -e
cd "$(dirname "$0")"

echo "📦 نصب وابستگی‌ها..."
npm install

echo "🚀 اجرای ربات..."
node index.js
