'use strict';

/**
 * ربات تلگرام با قابلیت‌های:
 *  ۱) پنل مدیریت محافظت‌شده با رمز (HKKINGROOT) برای ارسال پیام به همه گروه‌ها
 *  ۲) اتصال به OpenRouter:
 *      - تولید محتوا توسط هوش مصنوعی از داخل پنل و ارسال به گروه‌ها
 *      - پاسخ به ریپلای اعضا
 *  ۳) هنگام استارت / ارسال آیدی، پیام «سلام من آماده جواب دادنم» و آماده‌ی پاسخگویی
 */

const TelegramBot = require('node-telegram-bot-api');
const config = require('./config');
const storage = require('./storage');
const { complete } = require('./openrouter');

const bot = new TelegramBot(config.telegramToken, {
  polling: true,
  // دریافت رویداد عضویت/خروج ربات در گروه‌ها
  allowedUpdates: [
    'message',
    'edited_message',
    'callback_query',
    'my_chat_member',
  ],
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// اطلاعات ربات (شناسه و یوزرنیم)
let BOT_ID = null;
let BOT_USERNAME = '';

bot
  .getMe()
  .then((me) => {
    BOT_ID = me.id;
    BOT_USERNAME = (me.username || '').toLowerCase();
    console.log(`✅ ربات روشن شد: @${me.username} (id: ${me.id})`);
  })
  .catch((e) => {
    console.error('❌ دریافت اطلاعات ربات ناموفق بود:', e.message);
  });

bot.on('polling_error', (e) => console.error('⚠️ polling_error:', e.message));
bot.on('webhook_error', (e) => console.error('⚠️ webhook_error:', e.message));

// ---------------- متن‌های ثابت ----------------
const READY_TEXT =
  '👋 سلام! من آماده‌ی جواب دادنم.\n\n' +
  'هر سؤالی داری بپرس یا روی پیام من ریپلای بزن تا جوابت را بدهم. 🤖';

const SYSTEM_PROMPT =
  'تو یک دستیار هوشمند، مهربان و دقیق هستی. ' +
  'به زبانی که کاربر با آن صحبت می‌کند (معمولاً فارسی) پاسخ بده. ' +
  'پاسخ‌های کوتاه، واضح و مفید بده و از تکرار بیخود پرهیز کن.';

const WRITER_PROMPT =
  'تو یک نویسنده‌ی حرفه‌ای محتوا هستی. ' +
  'درباره‌ی موضوع یا دستوری که کاربر می‌دهد، یک پست کامل، خوانا و ساختاریافته به زبان فارسی بنویس. ' +
  'از پاراگراف‌بندی مناسب و در صورت نیاز از عنوان‌ها استفاده کن. ' +
  'لحن دوستانه اما حرفه‌ای داشته باش و متن را مستقیماً و بدون توضیح اضافه در ابتدا ارائه بده.';

// ---------------- صفحه‌کلیدها ----------------
const mainMenu = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '🛠 پنل مدیریت', callback_data: 'open_admin' }],
    ],
  },
};

const adminMenu = {
  reply_markup: {
    inline_keyboard: [
      [{ text: '📢 ارسال پیام به همه گروه‌ها', callback_data: 'admin_broadcast' }],
      [{ text: '🤖 تولید محتوا با هوش مصنوعی', callback_data: 'admin_ai_write' }],
      [{ text: '📊 آمار گروه‌ها', callback_data: 'admin_stats' }],
      [{ text: '🚪 خروج از پنل', callback_data: 'admin_exit' }],
    ],
  },
};

// ---------------- وضعیت‌ها و حافظه ----------------
const userState = new Map(); // chatId -> { state, ... }
const admins = new Set(); // مجموعه‌ی userId های احراز هویت‌شده
const conversations = new Map(); // `${chatId}:${userId}` -> [{role,content}]

function setState(chatId, state, data = {}) {
  userState.set(chatId, { state, ...data });
}
function clearState(chatId) {
  userState.delete(chatId);
}
function getState(chatId) {
  return userState.get(chatId);
}

function getHistory(key) {
  return conversations.get(key) || [];
}
function pushHistory(key, role, content) {
  const arr = getHistory(key);
  arr.push({ role, content });
  while (arr.length > config.maxHistory) arr.shift();
  conversations.set(key, arr);
}

// ---------------- توابع کمکی ----------------
function isAdmin(userId) {
  return admins.has(userId);
}

function openAdminLogin(chat) {
  // فقط در چت خصوصی مجاز است (برای امنیت، رمز نباید در گروه تایپ شود)
  if (chat.type !== 'private') {
    return bot.sendMessage(
      chat.id,
      '🔒 پنل مدیریت فقط در چت خصوصی (PV) قابل استفاده است.\n' +
        'لطفاً به پی‌وی ربات پیام دهید: /admin'
    );
  }
  setState(chat.id, 'awaiting_password');
  bot.sendMessage(chat.id, '🔑 برای ورود به پنل مدیریت، رمز عبور را وارد کنید:');
}

// پیام‌های طولانی را تکه‌تکه می‌کند (سقف تلگرام ۴۰۹۶ کاراکتر)
async function sendLongMessage(chatId, text, extra = {}) {
  const MAX = 3800;
  const chunks = [];
  if (!text) return null;
  if (text.length <= MAX) {
    chunks.push(text);
  } else {
    let remaining = text;
    while (remaining.length > MAX) {
      let cut = remaining.lastIndexOf('\n', MAX);
      if (cut <= 0) cut = MAX;
      chunks.push(remaining.slice(0, cut));
      remaining = remaining.slice(cut).replace(/^\n+/, '');
    }
    if (remaining) chunks.push(remaining);
  }

  let lastMsg = null;
  for (const c of chunks) {
    lastMsg = await bot.sendMessage(chatId, c, extra);
    await sleep(45);
  }
  return lastMsg;
}

// ارسال یک متن به تمام گروه‌های ثبت‌شده
async function broadcast(text) {
  const groups = storage.getGroups();
  let ok = 0;
  let fail = 0;

  for (const g of groups) {
    try {
      await sendLongMessage(g.id, text);
      ok++;
    } catch (e) {
      fail++;
      const desc = String(e.message || '');
      // اگر ربات از گروه حذف شده یا مسدود شده، آن گروه را از لیست برمی‌داریم
      if (/forbidden|not found|blocked|kicked|deactivated|chat_id/i.test(desc)) {
        storage.removeGroup(g.id);
      }
      console.error(`ارسال به گروه ${g.id} ناموفق:`, desc);
    }
    await sleep(60); // جلوگیری از محدودیت (flood)
  }

  return { ok, fail, total: groups.length };
}

// پاسخ هوش مصنوعی به یک کاربر
async function answerWithAI(msg, userText) {
  const chat = msg.chat;
  const key = `${chat.id}:${msg.from.id}`;
  const history = getHistory(key);

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...history,
    { role: 'user', content: userText },
  ];

  await bot.sendChatAction(chat.id, 'typing');

  const reply = await complete(messages, { models: config.aiModels });

  pushHistory(key, 'user', userText);
  pushHistory(key, 'assistant', reply);

  const opts = {};
  if (msg.reply_to_message) {
    opts.reply_to_message_id = msg.message_id;
  }
  await sendLongMessage(chat.id, reply, opts);
}

// ---------------- پردازش وضعیت‌های پنل مدیریت ----------------
async function handleState(msg, st) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;

  if (st.state === 'awaiting_password') {
    clearState(chatId);
    if (text && text.trim() === config.adminPassword) {
      admins.add(userId);
      await bot.sendMessage(
        chatId,
        '✅ ورود موفق بود! به پنل مدیریت خوش آمدید.',
        adminMenu
      );
    } else {
      await bot.sendMessage(chatId, '❌ رمز اشتباه است. دسترسی رد شد.');
    }
    return;
  }

  // سایر وضعیت‌ها فقط برای ادمین‌ها
  if (!isAdmin(userId)) {
    clearState(chatId);
    await bot.sendMessage(chatId, '⛔ شما به این بخش دسترسی ندارید.');
    return;
  }

  if (!text) {
    await bot.sendMessage(chatId, '⚠️ لطفاً یک متن بفرستید (فقط متن پشتیبانی می‌شود).');
    return;
  }

  if (st.state === 'awaiting_broadcast') {
    clearState(chatId);
    await bot.sendMessage(chatId, '⏳ در حال ارسال پیام به گروه‌ها...');
    const result = await broadcast(text);
    await bot.sendMessage(
      chatId,
      `✅ ارسال انجام شد.\n📨 موفق: ${result.ok}\n❌ ناموفق: ${result.fail}`,
      adminMenu
    );
    return;
  }

  if (st.state === 'awaiting_ai_topic') {
    clearState(chatId);
    await bot.sendMessage(chatId, '🧠 هوش مصنوعی در حال تولید متن است؛ لطفاً صبر کنید...');
    try {
      const generated = await complete(
        [
          { role: 'system', content: WRITER_PROMPT },
          { role: 'user', content: text },
        ],
        { models: config.aiModels }
      );
      const result = await broadcast(generated);
      const preview = generated.length > 1200 ? generated.slice(0, 1200) + '…' : generated;
      await bot.sendMessage(
        chatId,
        `✅ متن تولید و در گروه‌ها ارسال شد.\n` +
          `📨 موفق: ${result.ok}\n❌ ناموفق: ${result.fail}\n\n` +
          `——— پیش‌نمایش متن ———\n${preview}`,
        adminMenu
      );
    } catch (e) {
      await bot.sendMessage(
        chatId,
        `❌ خطا در تولید متن: ${e.message}`,
        adminMenu
      );
    }
    return;
  }
}

// ---------------- رویداد دکمه‌های شیشه‌ای (callback) ----------------
bot.on('callback_query', async (cq) => {
  const data = cq.data || '';
  const chat = cq.message ? cq.message.chat : null;
  const userId = cq.from.id;

  try {
    if (!chat) return;

    if (data === 'open_admin') {
      openAdminLogin(chat);
    } else if (data === 'admin_broadcast') {
      if (!isAdmin(userId))
        return bot.answerCallbackQuery(cq.id, { text: 'دسترسی ندارید' });
      setState(chat.id, 'awaiting_broadcast');
      bot.sendMessage(
        chat.id,
        '📝 متن پیام را بفرستید تا به همه گروه‌ها ارسال شود:'
      );
    } else if (data === 'admin_ai_write') {
      if (!isAdmin(userId))
        return bot.answerCallbackQuery(cq.id, { text: 'دسترسی ندارید' });
      setState(chat.id, 'awaiting_ai_topic');
      bot.sendMessage(
        chat.id,
        '🤖 موضوع یا دستور را بنویسید تا هوش مصنوعی متن تولید کند و در گروه‌ها ارسال شود:'
      );
    } else if (data === 'admin_stats') {
      if (!isAdmin(userId))
        return bot.answerCallbackQuery(cq.id, { text: 'دسترسی ندارید' });
      const groups = storage.getGroups();
      let text = `📊 تعداد گروه‌های ثبت‌شده: ${groups.length}`;
      if (groups.length) {
        text += '\n\n';
        groups.slice(0, 50).forEach((g, i) => {
          text += `${i + 1}. ${g.title || 'بدون عنوان'}\n`;
        });
      }
      bot.sendMessage(chat.id, text, adminMenu);
    } else if (data === 'admin_exit') {
      admins.delete(userId);
      clearState(chat.id);
      bot.sendMessage(chat.id, '🚪 از پنل مدیریت خارج شدید.', mainMenu);
    }

    bot.answerCallbackQuery(cq.id).catch(() => {});
  } catch (e) {
    console.error('callback error:', e.message);
    bot.answerCallbackQuery(cq.id).catch(() => {});
  }
});

// ---------------- رویداد عضویت/خروج در گروه ----------------
bot.on('my_chat_member', (update) => {
  try {
    const chat = update.chat;
    const status = update.new_chat_member && update.new_chat_member.status;
    if (['member', 'administrator'].includes(status)) {
      storage.addGroup(chat.id, { title: chat.title, type: chat.type });
      console.log(`➕ اضافه شد به گروه: ${chat.title} (${chat.id})`);
    } else if (['left', 'kicked'].includes(status)) {
      storage.removeGroup(chat.id);
      console.log(`➖ حذف شد از گروه: ${chat.title} (${chat.id})`);
    }
  } catch (e) {
    console.error('my_chat_member error:', e.message);
  }
});

// ---------------- پردازش پیام‌ها ----------------
bot.on('message', async (msg) => {
  try {
    const chat = msg.chat;
    const text = msg.text || '';
    const fromId = msg.from && msg.from.id;

    // ثبت خودکار گروه‌ها
    if (chat.type === 'group' || chat.type === 'supergroup') {
      storage.addGroup(chat.id, { title: chat.title, type: chat.type });
    }

    // --- دستورات ---
    if (/^\/start/i.test(text)) {
      clearState(chat.id);
      if (chat.type === 'group' || chat.type === 'supergroup') {
        return bot.sendMessage(
          chat.id,
          '✅ ربات فعال شد.\nبرای پرسش، روی پیام من ریپلای بزنید. 🤖'
        );
      }
      return bot.sendMessage(chat.id, READY_TEXT, mainMenu);
    }

    if (/^\/admin/i.test(text)) {
      clearState(chat.id);
      return openAdminLogin(chat);
    }

    if (/^\/id/i.test(text)) {
      const name =
        (msg.from && (msg.from.first_name || msg.from.username)) || 'دوست';
      return bot.sendMessage(
        chat.id,
        `🆔 شناسه (ID) شما:\n<code>${fromId}</code>\n\n` +
          `👋 سلام ${name}! من آماده‌ی جواب دادنم. 🤖\n` +
          `حالا می‌توانید سؤالتان را بپرسید یا روی پیام من ریپلای بزنید.`,
        { parse_mode: 'HTML' }
      );
    }

    if (/^\/help/i.test(text)) {
      return bot.sendMessage(
        chat.id,
        '📜 راهنما:\n\n' +
          '• برای گفتگو با من، در چت خصوصی پیام بدهید.\n' +
          '• در گروه، روی پیام من ریپلای بزنید تا جواب بدهم.\n' +
          '• /id — نمایش شناسه شما\n' +
          '• /admin — ورود به پنل مدیریت (فقط در PV)',
        mainMenu
      );
    }

    // --- پردازش وضعیت پنل مدیریت ---
    const st = getState(chat.id);
    if (st) {
      await handleState(msg, st);
      return;
    }

    // --- پاسخ هوش مصنوعی ---
    if (!text) return; // فقط متن

    const isPrivate = chat.type === 'private';
    const repliedFromBot =
      msg.reply_to_message &&
      msg.reply_to_message.from &&
      BOT_ID &&
      msg.reply_to_message.from.id === BOT_ID;

    const mentioned =
      BOT_USERNAME &&
      new RegExp(`@${BOT_USERNAME}\\b`, 'i').test(text);

    // در گروه فقط زمانی جواب می‌دهیم که روی پیام ربات ریپلای شده یا ربات منشن شده باشد
    if (!isPrivate && !repliedFromBot && !mentioned) return;

    await answerWithAI(msg, text);
  } catch (e) {
    console.error('message handler error:', e.message);
    try {
      await bot.sendMessage(
        msg.chat.id,
        '❌ الان نمی‌توانم پاسخ دهم. لطفاً کمی بعد دوباره تلاش کنید.'
      );
    } catch (_) {}
  }
});

console.log('🚀 ربات در حال اجراست... (polling)');
