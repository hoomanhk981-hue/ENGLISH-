import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ربات تلگرام هوشمند | پنل مدیریت + هوش مصنوعی",
  description:
    "ربات تلگرام با پنل مدیریت محافظت‌شده با رمز، ارسال گروهی پیام و اتصال به OpenRouter برای پاسخگویی هوشمند.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
