import type { ReactNode } from "react";

const features = [
  {
    icon: "🛠️",
    title: "پنل مدیریت با رمز",
    desc: "ورود به پنل با رمز HKKINGROOT. فقط در چت خصوصی (PV) باز می‌شود تا امن بماند.",
  },
  {
    icon: "📢",
    title: "ارسال به همه گروه‌ها",
    desc: "متنی تایپ می‌کنی و ربات آن را به تمام گروه‌هایی که عضو آن‌هاست می‌فرستد.",
  },
  {
    icon: "🧠",
    title: "تولید محتوا با AI",
    desc: "از داخل پنل موضوع می‌دهی، هوش مصنوعی (OpenRouter) متن می‌نویسد و در گروه‌ها می‌فرستد.",
  },
  {
    icon: "💬",
    title: "پاسخ به ریپلای اعضا",
    desc: "وقتی یک عضو روی پیام ربات ریپلای می‌زند، هوش مصنوعی جواب او را می‌دهد.",
  },
  {
    icon: "👋",
    title: "آماده‌ی پاسخگویی",
    desc: "با /start یا /id پیام «سلام، آماده‌ی جواب دادنم» را می‌دهد و بعد می‌توانی چت کنی.",
  },
  {
    icon: "♻️",
    title: "اجرا روی VPS لینوکس",
    desc: "آماده‌ی اجرا روی سرور لینوکسی با Node.js و اجرای دائمی با PM2.",
  },
];

const steps = [
  "فایل زیپ را دانلود و روی سرور (VPS) آپلود کن.",
  "فایل را باز کن، وارد پوشه‌ی telegram-bot شو و دستور npm install را بزن.",
  "دستور node index.js (یا pm2 start ecosystem.config.js) را اجرا کن.",
  "در تلگرام به ربات برو، /admin را بزن و رمز HKKINGROOT را وارد کن.",
];

function Card({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur transition hover:border-sky-400/40 hover:bg-white/10">
      {children}
    </div>
  );
}

export default function HomePage() {
  return (
    <main className="relative overflow-hidden">
      {/* پس‌زمینه‌ی گرادینت */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 right-0 h-96 w-96 rounded-full bg-sky-500/20 blur-3xl" />
        <div className="absolute top-1/3 -left-20 h-96 w-96 rounded-full bg-indigo-500/20 blur-3xl" />
      </div>

      <section className="mx-auto max-w-5xl px-6 py-16">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-sky-400/30 bg-sky-400/10 px-4 py-1.5 text-sm text-sky-300">
            🤖 ربات تلگرام + OpenRouter
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-tight sm:text-5xl">
            ربات تلگرام{" "}
            <span className="bg-gradient-to-l from-sky-400 to-indigo-400 bg-clip-text text-transparent">
              هوشمند
            </span>{" "}
            با پنل مدیریت
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-300">
            پنل مدیریت محافظت‌شده با رمز، ارسال گروهی پیام، تولید محتوا با هوش
            مصنوعی و پاسخگویی خودکار. آماده‌ی اجرا روی سرور لینوکس (VPS).
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <a
              href="/telegram-bot.zip"
              download
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-sky-500 to-indigo-500 px-7 py-3.5 text-base font-bold text-white shadow-lg shadow-sky-500/25 transition hover:from-sky-400 hover:to-indigo-400"
            >
              ⬇️ دانلود فایل زیپ ربات
            </a>
            <a
              href="https://t.me/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-7 py-3.5 text-base font-semibold text-slate-100 transition hover:bg-white/10"
            >
              تلگرام
            </a>
          </div>
          <p className="mt-3 text-sm text-slate-400">
            رمز پنل مدیریت:{" "}
            <code className="rounded bg-white/10 px-2 py-0.5 text-sky-300">
              HKKINGROOT
            </code>
          </p>
        </div>

        {/* ویژگی‌ها */}
        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Card key={f.title}>
              <div className="text-3xl">{f.icon}</div>
              <h3 className="mt-3 text-lg font-bold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-7 text-slate-300">{f.desc}</p>
            </Card>
          ))}
        </div>

        {/* راه‌اندازی */}
        <div className="mt-16 rounded-2xl border border-white/10 bg-white/5 p-8">
          <h2 className="text-2xl font-bold text-white">🚀 راه‌اندازی در ۴ قدم</h2>
          <ol className="mt-6 space-y-4">
            {steps.map((s, i) => (
              <li key={i} className="flex gap-4">
                <span className="flex h-8 w-8 flex-none items-center justify-center rounded-full bg-gradient-to-l from-sky-500 to-indigo-500 text-sm font-bold text-white">
                  {i + 1}
                </span>
                <p className="pt-1 leading-7 text-slate-200">{s}</p>
              </li>
            ))}
          </ol>

          <div className="mt-8 overflow-x-auto rounded-xl bg-slate-900/70 p-4 text-left">
            <pre className="text-sm text-emerald-300" dir="ltr">
              <code>{`# روی سرور لینوکس
cd telegram-bot
npm install
node index.js

# اجرای دائمی با PM2
sudo npm install -g pm2
pm2 start ecosystem.config.js
pm2 save && pm2 startup`}</code>
            </pre>
          </div>
        </div>

        {/* جعبه دانلود پایانی */}
        <div className="mt-16 rounded-2xl border border-sky-400/30 bg-gradient-to-l from-sky-500/10 to-indigo-500/10 p-8 text-center">
          <h2 className="text-2xl font-bold text-white">دانلود و اجرا</h2>
          <p className="mx-auto mt-3 max-w-xl text-slate-300">
            فایل زیپ شامل کل کد، تنظیمات و راهنمای فارسی است. توکن‌ها و رمز داخل
            کد قرار داده شده‌اند؛ فقط کافی است اجرا کنی.
          </p>
          <a
            href="/telegram-bot.zip"
            download
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-sky-500 to-indigo-500 px-8 py-4 text-base font-bold text-white shadow-lg shadow-sky-500/25 transition hover:from-sky-400 hover:to-indigo-400"
          >
            ⬇️ دریافت telegram-bot.zip
          </a>
        </div>

        <footer className="mt-16 text-center text-sm text-slate-500">
          ساخته‌شده با Node.js، node-telegram-bot-api و OpenRouter
        </footer>
      </section>
    </main>
  );
}
